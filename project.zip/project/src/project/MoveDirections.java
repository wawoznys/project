package project;

public enum MoveDirections {
    FORWARD,
    BACKWARD,
    RIGHT,
    LEFT
}
